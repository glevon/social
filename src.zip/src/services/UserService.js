import http from "../http-common"
import AuthHeader from './AuthHeader'
class UserService{
    getUserData(){
        return http.get('/profile',{headers:AuthHeader()})
    }
    edit(data){
        return http.post("/profile/edit",data,{headers:AuthHeader()})
    }
    changePassword(data){
        return http.post("/profile/changepas",data,{headers:AuthHeader()})
    }
    addProf(data){
        return http.post("/profile/addprof",data,{headers:AuthHeader()})
    }
    search(data){
        return http.post("/profile/search",{search:data},{headers:AuthHeader()})
    }
    addFriend(id){
        return http.post("/profile/addfriend",{id:id},{headers:AuthHeader()})

    }
}


export default new UserService()