import React, { Component } from "react";
import UserService from "../services/UserService"
import { Link } from "react-router-dom";
import '../CSS/Profile.css';
class Profile extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
      data:{},
      hide:"none",
      inp: {
        old_password: "",
        new_password: "",
        new_confirm_password: "",
      },
      errors:{},
      profPic:"",
      search:"",
      users:[],
       
    }
  }
  componentDidMount(){
    UserService.getUserData().then((r)=>{
    if (r.data.id) {
       this.state.data=r.data
      this.setState({})
    }
    else{
      this.props.history.push("/signin","Please Log in")
    }
  })
  }
  logout(){
    window.localStorage.removeItem('user');
    this.props.history.push("/signin","Please Log in")
  }
  toggle(){
    if (this.state.hide==="none") {
      this.state.hide="block"
    } else {
      this.state.hide="none"
    }
    this.setState({})

  }
  change(e){
      this.state.inp[e.target.getAttribute("data-id")] = e.target.value;
      this.setState({});
  }
  changeSearch(e) {
    this.state.users = [];
    this.state[e.target.getAttribute("data-id")] = e.target.value;
    this.setState({});
    UserService.search(this.state.search).then((r) => {
      if (this.state.search !== "") {
        this.state.users = r.data;
        this.setState({});
      }
    });
  }
  changePhoto(e){
    this.state[e.target.getAttribute("data-id")] = e.target.files[0];
    this.setState({});
}
addProfPic(){
  let formData= new FormData()
  formData.append("profPic",this.state.profPic)
  UserService.addProf(formData).then((r)=>{
    this.state.data.photo=r.data.filename
    this.state.hide="none"
    this.setState({})

  })
}
  changePassword(){
    // this.state.inp.id=this.state.data.id
    UserService.changePassword(this.state.inp)
    .then(r=>{
      if (r.data.length!==0) {
        this.state.errors = {}
        r.data.forEach((item)=>{
              this.state.errors[item.param]=item.msg
            })
            this.setState({})
        }
        else{
          this.state.errors = {}
          this.setState({})
          window.localStorage.removeItem('user');
          this.props.history.push("/signin","Password changed successfully. Please Sign in")
        }
    })
  }
  addFriend(id){
    UserService.addFriend(id)
    .then((r)=>console.log(r))
  }
  render() {
    return (
      <div>
          <div className="navi">
            <nav className="navbar navbar-expand-sm ">
            <ul className="navbar-nav">
            <li className="nav-item w-100 mh-100">
            <Link className="nav-link" to="/profile">
            Profile
            </Link>
            </li>
            </ul>
            <div className="search">
              <input
                      type="text"
                      placeholder="Search people"
                      className="form-control right m-1"
                      value={this.state.search}
                      data-id="search"
                      onChange={this.changeSearch.bind(this)}
                      />      
              <div style={{ width: "100%", minHeight: "1px",  background: "#9797ca", position:"absolute" }} className="m-1"  >
                {this.state.users.map((a) => (
                  <div key={a.id}>
                    <img
                      src={`http://localhost:8000/images/${a.photo}` }
                      alt=""
                      height="70px"
                      width="70px"
                    />
                    <b>
                      <p>
                        {a.name}
                        {a.surname}
                      </p>
                    </b>
                    <button className="btn btn-info" onClick={this.addFriend.bind(this,a.id)}>Add</button>
                  </div>
                ))}
              </div>
            </div>
            <img className="nimg" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR83ir23fx-r8o47Hh-SA1rAhE927hRGSuPfw&usqp=CAU" alt=""/>
              <button className="user" onClick={this.toggle.bind(this)}>
              <img className="img" src={`http://localhost:8000/images/${this.state.data.photo}`} alt=""/>
              </button>
            </nav>
            </div>
        <div className="myDIV" style={{display: this.state.hide}}>
          <img  className="img" src={`http://localhost:8000/images/${this.state.data.photo}`} alt=""/>
          <div data-toggle="modal" data-target="#exampleModalCenter1" className="im-up">
              <img className="img" src="https://www.clipartmax.com/png/small/281-2810310_png-file-cloud-upload-icon.png" alt=""/>
          </div>
          <h3>{this.state.data.name} {this.state.data.surname}</h3>
          <h3>{this.state.data.email}</h3>
          <Link className="btn btn-primary p-2 " to="/profile/edit"> Manage your Account </Link>
          <button  className="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
          Change Password
           </button>
          <button  onClick={this.logout.bind(this)}  className="btn btn-secondary p-2">Logout</button>
        </div>
        <div className="modal fade" id="exampleModalCenter1" tabIndex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div className="modal-dialog modal-dialog-centered" role="document">
                  <div className="modal-content">
                    <div className="modal-header">
                      <h5 className="modal-title" id="exampleModalLongTitle">Change Password</h5>
                      <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                      <div className="modal-body">
                          <input
                              type="file"
                              className="form-control m-2"
                              accept="image/*"
                              data-id="profPic"
                              onChange={this.changePhoto.bind(this)}
                          />
                    </div>
                    <div>
                    <div className="modal-footer">
                      <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                      <button onClick={this.addProfPic.bind(this)}  type="button" className="btn btn-primary">Add Propile pic</button>
                    </div>
                  </div>
                </div>
          </div>
      </div>
        <div className="modal fade" id="exampleModalCenter" tabIndex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div className="modal-dialog modal-dialog-centered" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="exampleModalLongTitle">Change Password</h5>
                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div className="modal-body">
              <input
                type="password"
                placeholder="Enter your old password"
                className="form-control m-2"
                value={this.state.inp.old_password}
                data-id="old_password"
                onChange={this.change.bind(this)}
              />
                {this.state.errors.old_password ? (
                <div className="alert alert-danger m-2 w-100">{this.state.errors.old_password}</div>
              ) : null}
              <input
                type="password"
                placeholder="Enter your new password"
                className="form-control m-2"
                value={this.state.inp.new_password}
                data-id="new_password"
                onChange={this.change.bind(this)}
              />
                {this.state.errors.new_password ? (
                <div className="alert alert-danger m-2 w-100">{this.state.errors.new_password}</div>
              ) : null}
              <input
                type="password"
                placeholder="Confirm your new password"
                className="form-control m-2"
                value={this.state.inp.new_confirm_password}
                data-id="new_confirm_password"
                onChange={this.change.bind(this)}
              />
                {this.state.errors.new_confirm_password ? (
                <div className="alert alert-danger m-2 w-100">{this.state.errors.new_confirm_password}</div>
              ) : null}
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                <button onClick={this.changePassword.bind(this)}  type="button" className="btn btn-primary">Save changes</button>
              </div>
            </div>
          </div>
        </div>

        <h1>Profile</h1>
        
          {/* {this.props.location.state ? (
            <h3 className=" alert alert-success">{this.props.location.state}</h3>
          ) : null} */}
        <h1>{this.state.data.name}</h1>
        <h2>{this.state.data.email}</h2>

      </div>
    );
  }
}

export default Profile;
